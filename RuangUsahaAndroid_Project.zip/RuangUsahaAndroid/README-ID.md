# Ruang Usaha Android — proyek sumber

Fitur Manajemen Usaha:
- Tambah usaha dengan nama dan jenis yang diisi pengguna.
- Edit nama dan jenis usaha.
- Arsipkan dan aktifkan kembali tanpa menghapus catatan usaha.
- Contoh awal: Studio Foto, Toko Alarm Shopee, CCTV & Service, Layanan Delivery.
- Identitas usaha memakai ID unik; nama dapat diubah tanpa mengganti ID.

Build APK: buka folder ini di Android Studio, tunggu Gradle Sync, lalu pilih Build → Build Bundle(s) / APK(s) → Build APK(s). APK debug biasanya berada di app/build/outputs/apk/debug/app-debug.apk.

Catatan: ini proyek sumber, belum APK terkompilasi. Data disimpan lokal. Ekspor Excel memerlukan internet pada versi ini. Manajemen usaha sudah tersedia, tetapi transaksi/stok/HPP belum dikaitkan ke ID usaha; integrasi itu diperlukan untuk laporan laba-rugi per usaha yang akurat.


## Build APK tanpa memasang Android Studio (GitHub Actions)
1. Buat repository GitHub baru dan unggah semua isi folder proyek ini.
2. Buka tab **Actions** di repository.
3. Pilih workflow **Build Ruang Usaha APK**, lalu tekan **Run workflow** (atau push ke branch `main`).
4. Setelah job selesai, unduh artifact **RuangUsaha-debug-apk** dari halaman run workflow.
5. Ekstrak artifact ZIP untuk memperoleh `app-debug.apk`.

APK debug ini untuk pemasangan/testing pribadi, bukan rilis Play Store. Workflow harus dijalankan di GitHub; APK belum dibangun di lingkungan pembuatan file ini karena Android SDK dan Gradle tidak tersedia di sini.
